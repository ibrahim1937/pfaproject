@extends('admin.master')


@section('title')

<title>Dashboard</title>

@endsection


@section('content')

    <div class="container-fluid">
        
    </div>



@endsection